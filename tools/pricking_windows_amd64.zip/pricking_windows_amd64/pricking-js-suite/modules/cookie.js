console.log("Loaded Cookie Module ...");

export function getCookie() {
    console.log(document.cookie);
}

