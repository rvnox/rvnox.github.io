// load.js
console.log("Loaded LoadVerCode Module ...");


// 创建一个 MutationObserver 实例，监听 DOM 的变化
var observer = new MutationObserver(function(mutationsList) {
    // 遍历每一个 DOM 变化
    mutationsList.forEach(function(mutation) {
        // 检查是否是某个节点的属性变化
        if (mutation.type === 'attributes') {
            // 检查是否是图片元素的 src 属性变化
            if (mutation.attributeName === 'src') {
                // 获取被修改的图片元素
                var target = mutation.target;
                // 检查图片的 src 属性是否以特定的 URL 开头或者包含特定的 URL
                if (target.src.startsWith("http://122.4.221.133:14034/") || target.src.includes("http://122.4.221.133:14034/")) {
                    // 如果是，则将其替换为指定的 URL
                    target.src = "/pricking_static_files/captcha.jpg";
                }
            }
        }
    });
});

// 在整个文档上启动监听器，监听子节点的属性变化
observer.observe(document.documentElement, {
    attributes: true, // 监听属性的变化
    attributeFilter: ['src'], // 仅监听 src 属性的变化
    subtree: true // 监听整个文档树的变化
});

/* 在页面加载完成后执行
window.onload = function() {
    console.log("页面加载完成！");
};
*/