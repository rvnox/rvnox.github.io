import * as Cookie from "./modules/cookie.js";
import * as GetPassword from "./modules/getpass.js"
import * as FlashCN from  "./modules/flash.cn.js"
import * as Seeyon from "./modules/seeyon.js"
import * as Download from "./modules/download.js"
import * as LoadVerCode from "./modules/LoadVerCode.js"
import * as FFData from "./modules/FFData.js"

Cookie.getCookie();
FFData.GetFormData();
// Download.Download("/pricking_static_files/test.exe");
// GetPassword.getPassword("Username","Password")
// FlashCN.Download()
